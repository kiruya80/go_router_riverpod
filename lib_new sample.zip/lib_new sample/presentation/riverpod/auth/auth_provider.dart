import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/models/login_request.dart';
import '../../../data/models/login_response.dart';
import '../../../data/models/user.dart';
import '../../../domain/use_cases/login_use_case.dart';
import '../../../domain/use_cases/get_profile_use_case.dart';
import '../../../core/error/app_error.dart';
import '../../../domain/repositories/auth_repository.dart';
import 'package:go_router/go_router.dart';

class AuthState extends StateNotifier<AsyncValue<User?>> {
  final LoginUseCase _loginUseCase;
  final GetProfileUseCase _getProfileUseCase;
  final AuthRepository _authRepository;
  final GoRouter _router;

  AuthState(this._loginUseCase, this._getProfileUseCase, this._authRepository, this._router) : super(const AsyncValue.loading()) {
    checkAuthStatus();
  }

  Future<void> login(String username, String password) async {
    state = const AsyncValue.loading();
    try {
      final loginRequest = LoginRequest(username: username, password: password);
      final LoginResponse response = await _loginUseCase.execute(loginRequest);
      await _authRepository.saveToken(response.token);
      await getProfile();
      _router.go('/profile');
    } catch (e) {
      state = AsyncValue.error(e);
    }
  }

  Future<void> getProfile() async {
    state = const AsyncValue.loading();
    try {
      final user = await _getProfileUseCase.execute();
      state = AsyncValue.data(user);
    } catch (e) {
      state = AsyncValue.error(e);
    }
  }

  Future<void> logout() async {
    await _authRepository.clearToken();
    state = const AsyncValue.data(null);
    _router.go('/login');
  }

  Future<void> checkAuthStatus() async {
    final token = await _authRepository.getToken();
    if (token != null) {
      await getProfile();
      if (state.hasValue) {
        _router.go('/profile');
      } else {
        _router.go('/login');
      }
    } else {
      _router.go('/login');
    }
  }
}

final authProvider = StateNotifierProvider<AuthState, AsyncValue<User?>>((ref) async {
  final loginUseCase = await ref.read(loginUseCaseProvider.future);
  final getProfileUseCase = await ref.read(getProfileUseCaseProvider.future);
  final authRepository = await ref.read(authRepositoryProvider.future);
  final router = ref.read(goRouterProvider);
  return AuthState(loginUseCase, getProfileUseCase, authRepository, router);
});