class AppError implements Exception {
  final String message;

  AppError(this.message);

  @override
  String toString() => 'AppError: $message';
}

class NetworkError extends AppError {
  NetworkError(String message) : super(message);
}

class UnauthorizedError extends AppError {
  UnauthorizedError(String message) : super(message);
}